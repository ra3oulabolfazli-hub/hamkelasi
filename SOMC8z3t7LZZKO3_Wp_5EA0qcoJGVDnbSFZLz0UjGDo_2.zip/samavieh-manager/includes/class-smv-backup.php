<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * سیستم پشتیبان‌گیری و بروزرسانی هوشمند سمایه
 * - بک‌اپ کامل دیتابیس (جداول وردپرس + جدول‌های افزونه)
 * - بک‌اپ فایل‌های افزونه، قالب و آپلودها
 * - بازسازی از نسخه پشتیبان
 * - بررسی آپدیت‌های موجود (وردپرس، افزونه‌ها، قالب‌ها)
 */
class SMV_Backup {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'), 30);
        add_action('admin_post_smv_backup_now', array(__CLASS__, 'backup_now'));
        add_action('admin_post_smv_restore_backup', array(__CLASS__, 'restore_backup'));
        add_action('admin_post_smv_delete_backup', array(__CLASS__, 'delete_backup'));
        add_action('admin_init', array(__CLASS__, 'schedule_backup'));
        add_action('admin_notices', array(__CLASS__, 'admin_notices'));
    }

    public static function admin_menu() {
        add_submenu_page(
            'smv-dashboard',
            'پشتیبان‌گیری و بروزرسانی',
            'پشتیبان‌گیری و بروزرسانی',
            'manage_smv_registrations',
            'smv-backup',
            array(__CLASS__, 'render_page')
        );
    }

    public static function admin_notices() {
        $page = get_current_screen();
        if (!$page || $page->id !== 'toplevel_page_smv-dashboard' && strpos($page->id, 'smv-backup') === false) {
            return;
        }
        if (isset($_GET['smv_backup_done'])) {
            echo '<div class="notice notice-success is-dismissible"><p>نسخه پشتیبان با موفقیت ایجاد شد.</p></div>';
        }
        if (isset($_GET['smv_restored'])) {
            echo '<div class="notice notice-success is-dismissible"><p>بازسازی نسخه پشتیبان با انجام شد.</p></div>';
        }
        if (isset($_GET['smv_deleted'])) {
            echo '<div class="notice notice-success is-dismissible"><p>نسخه پشتیبان حذف شد.</p></div>';
        }
        if (isset($_GET['smv_backup_error'])) {
            echo '<div class="notice notice-error is-dismissible"><p>خطا در ایجاد نسخه پشتیبان: ' . esc_html(wp_unslash($_GET['smv_backup_error'])) . '</p></div>';
        }
    }

    public static function render_page() {
        if (!current_user_can('manage_smv_registrations')) {
            wp_die('دسترسی لازم را ندارید.');
        }

        $backup_dir = WP_CONTENT_DIR . '/samavieh-backups';
        $backups = array();
        if (is_dir($backup_dir)) {
            $files = scandir($backup_dir);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $path = $backup_dir . '/' . $file;
                if (is_file($path)) {
                    $backups[] = array(
                        'name' => $file,
                        'size' => size_format(filesize($path)),
                        'date' => date('Y/m/d H:i', filemtime($path)),
                        'path' => $path,
                    );
                }
            }
            usort($backups, function($a, $b) {
                return filemtime($b['path']) <=> filemtime($a['path']);
            });
        }

        // Smart update checks
        $update_checks = self::check_updates();

        ?>
        <div class="wrap smv-admin-wrap" dir="rtl">
            <div class="smv-admin-heading">
                <div>
                    <span class="smv-admin-kicker">نسخه‌یافت و بازسازی</span>
                    <h1>پشتیبان‌گیری و بروزرسانی هوشمند</h1>
                    <p>قبل از هر تغییر مهم در سایت، یک نسخه پشتیبان بگیرید. در صورت نیاز می‌توانید به نسخه قبلی بازگردید.</p>
                </div>
            </div>

            <section class="smv-admin-card">
                <div class="smv-card-title-row"><div><h2>پشتیبان‌گیری فوری</h2><p>نسخه پشتیبان از دیتابیس و فایل‌های مهم سماویه را ذخیره می‌کند.</p></div></div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('smv_backup_action'); ?>
                    <input type="hidden" name="action" value="smv_backup_now" />
                    <button type="submit" class="button smv-primary-button">ایجاد نسخه پشتیبان فوری</button>
                </form>
                <p class="smv-settings-help">در بک‌اپ شامل: کل دیتابیس وردپرس، فایل‌های افزونه سماویه، قالب فعال و پوشهٔ آپلودها.</p>
            </section>

            <section class="smv-admin-card">
                <div class="smv-card-title-row"><div><h2>نسخه‌های پشتیبان موجود</h2><p>لیست نسخه‌های ذخیره‌شده برای بازسازی یا حذف.</p></div></div>
                <?php if ($backups) : ?>
                    <table class="smv-backup-table">
                        <thead><tr><th>نام فایل</th><th>حجم</th><th>تاریخ ایجاد</th><th>عملیات</th></tr></thead>
                        <tbody>
                        <?php foreach ($backups as $backup) : ?>
                            <tr>
                                <td><?php echo esc_html($backup['name']); ?></td>
                                <td><?php echo esc_html($backup['size']); ?></td>
                                <td><?php echo esc_html($backup['date']); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <?php wp_nonce_field('smv_backup_action'); ?>
                                        <input type="hidden" name="action" value="smv_restore_backup" />
                                        <input type="hidden" name="backup_file" value="<?php echo esc_attr($backup['path']); ?>" />
                                        <button type="submit" class="button button-small" onclick="return confirm('از بازسانی این نسخه مطمئن هستید؟ همه تغییرات فعلی بازмен될 است.')">بازسازی</button>
                                    </form>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;margin-left:6px;">
                                        <?php wp_nonce_field('smv_backup_action'); ?>
                                        <input type="hidden" name="action" value="smv_delete_backup" />
                                        <input type="hidden" name="backup_file" value="<?php echo esc_attr($backup['path']); ?>" />
                                        <button type="submit" class="button button-small smv-danger-button" onclick="return confirm('این نسخه پشتیبان برای همیشه حذف شود؟')">حذف</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <div class="smv-admin-empty"><span>📦</span><p>هنوز نسخه پشتیبان ایجاد نشده است.</p></div>
                <?php endif; ?>
            </section>

            <section class="smv-admin-card">
                <div class="smv-card-title-row"><div><h2>بروزرسانی هوشمند از طریق فایل ZIP یا JSON</h2><p>فایل آپدیت (.zip) یا فایل begleی (.json) یکی از آن‌ها را انتخاب کنید. سیستم نسخه جدید را جایگزین فایل‌های فعلی می‌کند.</p></div></div>
                <form id="smv-smart-update-form" enctype="multipart/form-data">
                    <?php wp_nonce_field('smv_smart_update'); ?>
                    <div class="smv-settings-grid">
                        <div class="smv-admin-field full">
                            <label for="smv_update_zip"><strong>فایل آپدیت (.zip)</strong></label>
                            <input type="file" id="smv_update_zip" name="smv_update_zip" accept=".zip" />
                            <small>فایل ZIP حاوی نسخه جدید افزونه سماویه.</small>
                        </div>
                        <div class="smv-admin-field full">
                            <label for="smv_update_json"><strong>فایل begleی (.json)</strong></label>
                            <input type="file" id="smv_update_json" name="smv_update_json" accept=".json" />
                            <small>فایل JSON حاوی اطلاعات نسخه (مثلاً: {"version":"1.3.6"}).</small>
                        </div>
                        <div class="smv-admin-field full" style="color:#8a6427; font-size:11px; margin-top:8px;">
                            <strong>نکته:</strong> فقط یکی از فایل‌های ZIP یا JSON کافی است؛ هر دو الزامی نیستند.
                        </div>
                    </div>
                    <button type="submit" class="button smv-primary-button" id="smv-smart-update-btn">اعمال بروزرسانی</button>
                </form>
                <div id="smv-smart-update-result" style="margin-top:15px; padding:12px; border-radius:8px; display:none;"></div>
                <script>
                jQuery(document).ready(function($){
                    var smv_ajax_url = typeof ajaxurl !== 'undefined' ? ajaxurl : '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
                    $('#smv-smart-update-form').on('submit', function(e){
                        e.preventDefault();
                        var btn = $('#smv-smart-update-btn');
                        var result = $('#smv-smart-update-result');
                        btn.prop('disabled', true).text('در حال پردازش…');
                        result.hide().removeClass().empty();
                        var formData = new FormData(this);
                        formData.append('action', 'smv_smart_update');
                        formData.append('_wpnonce', $('input[name="_wpnonce"]').val());
                        $.ajax({
                            url: smv_ajax_url,
                            type: 'POST',
                            data: formData,
                            processData: false,
                            contentType: false,
                            success: function(resp){
                                if (resp.success) {
                                    result.removeClass().addClass('smv-admin-card').css('background','#e4f4eb').css('border','1px solid #388367').css('color','#176245');
                                    result.html('<strong>✅ موفق:</strong> ' + resp.data.message).show();
                                    setTimeout(function(){ window.location.href = resp.data.redirect; }, 1500);
                                } else {
                                    result.removeClass().addClass('smv-admin-card').css('background','#fde9e7').css('border','1px solid #dfbcbc').css('color','#944545');
                                    result.html('<strong>❌ خطا:</strong> ' + resp.data.message).show();
                                    btn.prop('disabled', false).text('اعمال بروزرسانی');
                                }
                            },
                            error: function(xhr){
                                var msg = 'ارتباط با سرور برقرار نشد.';
                                if (xhr.responseJSON && xhr.responseJSON.message) msg = xhr.responseJSON.message;
                                result.removeClass().addClass('smv-admin-card').css('background','#fde9e7').css('border','1px solid #dfbcbc').css('color','#944545');
                                result.html('<strong>❌ خطا:</strong> ' + msg).show();
                                btn.prop('disabled', false).text('اعمال بروزرسانی');
                            }
                        });
                    });
                });
                </script>
                <p class="smv-settings-help">توجه: قبل از هر بروزرسانی، حتماً یک نسخه پشتیبان بگیرید. افزونه‌های خریداری شده را از طریق ZIP در پیشخوان وردپرس نصب کنید.</p>
            </section>

            <section class="smv-admin-card">
                <div class="smv-card-title-row"><div><h2>بروزرسانی هوشمند (تله‌اتوماتیک)</h2><p>سیستم نسخه‌های جدید وردپرس، قالب‌ها و افزونه‌ها را بررسی می‌کند.</p></div></div>
                <div class="smv-update-grid">
                    <?php foreach ($update_checks as $check) : ?>
                        <div class="smv-update-card <?php echo esc_attr($check['class']); ?>">
                            <div class="smv-update-icon"><?php echo esc_html($check['icon']); ?></div>
                            <div class="smv-update-info">
                                <div class="smv-update-title"><?php echo esc_html($check['title']); ?></div>
                                <div class="smv-update-status"><?php echo esc_html($check['status']); ?></div>
                            </div>
                            <?php if (!empty($check['url'])) : ?>
                                <a href="<?php echo esc_url($check['url']); ?>" class="button smv-update-btn">بروزرسانی</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        <?php
    }

    /**
     * بررسی آپدیت‌های موجود
     */
    private static function check_updates() {
        $checks = array();

                    // WordPress core
        $core_update = get_site_option('update_core');
        if (is_object($core_update)) {
            $updates = (array) $core_update;
            if (!empty($updates['updates'])) {
                foreach ($updates['updates'] as $u) {
                    $checks[] = array(
                        'title' => ' هسته وردپرس ' . esc_html($u->response ?: ''),
                        'status' => isset($u->response) && $u->response === 'upgrade' ? 'آپدیت موجود است' : 'به‌روز است',
                        'class' => isset($u->response) && $u->response === 'upgrade' ? 'needs-update' : 'up-to-date',
                        'icon' => '🔧',
                        'url' => network_admin_url('update-core.php'),
                    );
                }
            }
        }
        if (empty($checks)) {
            $checks[] = array(
                'title' => 'هسته وردپرس',
                'status' => 'به‌روز است',
                'class' => 'up-to-date',
                'icon' => '🔧',
            );
        }

        // Plugins
        $plugin_updates = (array) get_site_option('update_plugins');
        $has_plugin_update = false;
        if (!empty($plugin_updates['response'])) {
            foreach ($plugin_updates['response'] as $plugin_file => $data) {
                if (is_array($data)) {
                    foreach ($data as $plugin_update) {
                        if (is_object($plugin_update) && !empty($plugin_update->new_version)) {
                            $has_plugin_update = true;
                            $checks[] = array(
                                'title' => 'افزونه ' . esc_html($plugin_update->plugin ?: $plugin_file),
                                'status' => 'نسخه جدید: ' . esc_html($plugin_update->new_version),
                                'class' => 'needs-update',
                                'icon' => '🧩',
                                'url' => admin_url('update.php?plugin=' . $plugin_file),
                            );
                        }
                    }
                }
            }
        }
        if (!$has_plugin_update) {
            $checks[] = array(
                'title' => 'افزونه‌های نصب‌شده',
                'status' => 'همه به‌روز هستند',
                'class' => 'up-to-date',
                'icon' => '🧩',
            );
        }

        // Themes
        $theme_updates = (array) get_site_option('update_themes');
        $has_theme_update = false;
        if (!empty($theme_updates['response'])) {
            foreach ($theme_updates['response'] as $theme => $data) {
                if (is_object($data) && !empty($data->new_version)) {
                    $has_theme_update = true;
                    $checks[] = array(
                        'title' => 'قالب ' . esc_html($data->theme ?: $theme),
                        'status' => 'نسخه جدید: ' . esc_html($data->new_version),
                        'class' => 'needs-update',
                        'icon' => '🎨',
                        'url' => admin_url('themes.php?page=updates'),
                    );
                }
            }
        }
        if (!$has_theme_update) {
            $checks[] = array(
                'title' => 'قالب‌های نصب‌شده',
                'status' => 'همه به‌روز هستند',
                'class' => 'up-to-date',
                'icon' => '🎨',
            );
        }

        return $checks;
    }

    public static function schedule_backup() {
        if (!wp_next_scheduled('smv_scheduled_backup')) {
            wp_schedule_event(time(), 'twicedaily', 'smv_scheduled_backup');
        }
    }

    public static function backup_now() {
        if (!current_user_can('manage_smv_registrations')) {
            wp_die('دسترسی لازم را ندارید.');
        }
        check_admin_referer('smv_backup_action');

        $backup_dir = WP_CONTENT_DIR . '/samavieh-backups';
        if (!is_dir($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }

        $filename = 'samavieh-backup-' . gmdate('Y-m-d-H-i-s') . '.zip';
        $zip_path = $backup_dir . '/' . $filename;

        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            // ۱) دیتابیس — export تمام جداول
            $db_sql = self::export_database();
            if ($db_sql) {
                $zip->addFromString('database/' . gmdate('Y-m-d-H-i-s') . '-samavieh-database.sql', $db_sql);
            }

            // ۲) فایل‌های افزونه سماویه
            $plugin_dir = WP_PLUGIN_DIR . '/samavieh-manager';
            if (is_dir($plugin_dir)) {
                self::add_dir_to_zip($plugin_dir, $zip, 'plugin/samavieh-manager/');
            }

            // ۳) قالب فعال
            $theme_dir = get_stylesheet_directory();
            if (is_dir($theme_dir)) {
                self::add_dir_to_zip($theme_dir, $zip, 'theme/' . basename($theme_dir) . '/');
            }

            // ۴) پوشهٔ آپلودها (فقط فایل‌های مهم، نه کش)
            $uploads_dir = WP_CONTENT_DIR . '/uploads';
            if (is_dir($uploads_dir)) {
                self::add_dir_to_zip($uploads_dir, $zip, 'uploads/');
            }

            $zip->close();
        } else {
            wp_safe_redirect(add_query_arg('smv_backup_error', 'نمی‌توان فایل ZIP را ایجاد کرد.', admin_url('admin.php?page=smv-backup')));
            exit;
        }

        wp_safe_redirect(add_query_arg('smv_backup_done', '1', admin_url('admin.php?page=smv-backup')));
        exit;
    }

    public static function restore_backup() {
        if (!current_user_can('manage_smv_registrations')) {
            wp_die('دسترسی لازم را ندارید.');
        }
        check_admin_referer('smv_backup_action');

        $file = isset($_POST['backup_file']) ? sanitize_text_field($_POST['backup_file']) : '';
        if (!$file || !is_file($file)) {
            wp_safe_redirect(add_query_arg('smv_backup_error', 'فایل پشتیبان پیدا نشد.', admin_url('admin.php?page=smv-backup')));
            exit;
        }

        $zip = new ZipArchive();
        if ($zip->open($file) === true) {
            $extract_dir = WP_CONTENT_DIR . '/samavieh-backups/_restore_' . gmdate('Y-m-d-H-i-s');
            wp_mkdir_p($extract_dir);
            $zip->extractTo($extract_dir);
            $zip->close();

            // بازسازی دیتابیس اگر وجود داشته باشد
            $db_files = glob($extract_dir . '/database/*.sql');
            if (!empty($db_files)) {
                $db_file = $db_files[0];
                self::import_database($db_file);
            }

            // بازسازی فایل‌های افزونه
            $plugin_restore = $extract_dir . '/plugin/samavieh-manager';
            if (is_dir($plugin_restore)) {
                $dest = WP_PLUGIN_DIR . '/samavieh-manager';
                if (is_dir($dest)) {
                    self::remove_dir($dest);
                }
                self::copy_dir($plugin_restore, $dest);
            }

            wp_safe_redirect(add_query_arg('smv_restored', '1', admin_url('admin.php?page=smv-backup')));
        } else {
            wp_safe_redirect(add_query_arg('smv_backup_error', 'نمی‌توان فایل ZIP را باز کرد.', admin_url('admin.php?page=smv-backup')));
        }
        exit;
    }

    public static function delete_backup() {
        if (!current_user_can('manage_smv_registrations')) {
            wp_die('دسترسی لازم را ندارید.');
        }
        check_admin_referer('smv_backup_action');
        $file = isset($_POST['backup_file']) ? sanitize_text_field($_POST['backup_file']) : '';
        if ($file && is_file($file)) {
            @unlink($file);
        }
        wp_safe_redirect(admin_url('admin.php?page=smv-backup&smv_deleted=1'));
        exit;
    }

    /*──────────────────────────────────────────────
     * دیتابیس: export / import
     *────────────────────────────────────────────*/

    private static function export_database() {
        global $wpdb;
        $tables = $wpdb->get_col("SHOW TABLES");
        if (empty($tables)) {
            return false;
        }

        $sql = "-- Samavieh Database Backup -- " . gmdate('Y-m-d H:i:s') . "\n";
        $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        foreach ($tables as $table) {
            $sql .= "-- Table: {$table}\n";
            $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";

            $create = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_A);
            if ($create) {
                $sql .= $create['Create Table'] . ";\n\n";
            }

            $rows = $wpdb->get_results("SELECT * FROM `{$table}`", ARRAY_A);
            if (!empty($rows)) {
                $columns = array_keys($rows[0]);
                $col_list = '`' . implode('`, `', $columns) . '`';
                $chunk = array_chunk($rows, 100);
                foreach ($chunk as $batch) {
                    $values = array();
                    foreach ($batch as $row) {
                        $escaped = array();
                        foreach ($columns as $col) {
                            $val = $row[$col];
                            if ($val === null) {
                                $escaped[] = 'NULL';
                            } elseif (is_bool($val)) {
                                $escaped[] = $val ? '1' : '0';
                            } else {
                                $escaped[] = "'" . $wpdb->_escape($val) . "'";
                            }
                        }
                        $values[] = '(' . implode(',', $escaped) . ')';
                    }
                    $sql .= "INSERT INTO `{$table}` ({$col_list}) VALUES\n" . implode(",\n", $values) . ";\n\n";
                }
            }
        }

        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        return $sql;
    }

    private static function import_database($sql_file) {
        global $wpdb;
        if (!is_file($sql_file)) {
            return false;
        }
        $sql = file_get_contents($sql_file);
        if (!$sql) {
            return false;
        }
        // اجرای کوئری‌ها (ساده: جداکردن بر اساس ;)
        $queries = array_filter(array_map('trim', explode(';', $sql)));
        foreach ($queries as $query) {
            if (empty($query) || strpos($query, '--') === 0) {
                continue;
            }
            $wpdb->query($query);
        }
        return true;
    }

    /*──────────────────────────────────────────────
     * ZIP helpers
     *────────────────────────────────────────────*/

    private static function add_dir_to_zip($dir, $zip, $relative = '') {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $path = $dir . '/' . $file;
            $zip_path = $relative . $file;
            if (is_dir($path)) {
                $zip->addEmptyDir($zip_path . '/');
                self::add_dir_to_zip($path, $zip, $zip_path . '/');
            } else {
                //skip cache files
                if (strpos($file, '.log') !== false || strpos($file, '.tmp') !== false) {
                    continue;
                }
                $zip->addFile($path, $zip_path);
            }
        }
    }

    private static function copy_dir($src, $dst) {
        $dir = opendir($src);
        if (!is_dir($dst)) {
            wp_mkdir_p($dst);
        }
        while (false !== ($file = readdir($dir))) {
            if ($file === '.' || $file === '..') continue;
            $src_path = $src . '/' . $file;
            $dst_path = $dst . '/' . $file;
            if (is_dir($src_path)) {
                self::copy_dir($src_path, $dst_path);
            } else {
                copy($src_path, $dst_path);
            }
        }
        closedir($dir);
    }

    private static function remove_dir($dir) {
        if (!is_dir($dir)) return true;
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                self::remove_dir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
        return true;
    }
}