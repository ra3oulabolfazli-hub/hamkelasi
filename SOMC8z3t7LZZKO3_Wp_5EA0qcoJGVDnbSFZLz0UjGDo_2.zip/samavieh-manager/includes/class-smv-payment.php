<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * اتصال به درگاه پرداخت (زرین‌پال و سایر درگاه‌ها)
 */
class SMV_Payment {

    public static function init() {
        add_shortcode('samavieh_payment', array(__CLASS__, 'payment_shortcode'));
        add_action('admin_post_smv_verify_payment', array(__CLASS__, 'verify_payment'));
        add_action('wp_ajax_smv_verify_payment', array(__CLASS__, 'verify_payment_ajax'));
    }

    public static function payment_shortcode($atts) {
        $atts = shortcode_atts(array(
            'registration_id' => 0,
            'amount' => 0,
        ), $atts, 'samavieh_payment');

        $reg_id = absint($atts['registration_id']);
        $amount = absint($atts['amount']);

        if (!$reg_id || !$amount) {
            return '<div class="smv-notice smv-notice-error">اطلاعات پرداخت نامعتبر است.</div>';
        }

        global $wpdb;
        $table = smv_table_name();
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . $table . ' WHERE id = %d', $reg_id));
        if (!$row) {
            return '<div class="smv-notice smv-notice-error">ثبت‌نام پیدا نشد.</div>';
        }

        $zarinpal_merchant = smv_get_option('zarinpal_merchant', '');
        if (!$zarinpal_merchant) {
            return '<div class="smv-notice smv-notice-info">درگاه پرداخت فعال نیست. لطفاً از طریق فیش واریزی ثبت‌نام کنید.</div>';
        }

        $callback_url = admin_url('admin-post.php?action=smv_verify_payment&registration_id=' . $reg_id);
        $request_url = 'https://api.zarinpal.com/pg/v4/payment/request.json';

        ob_start();
        ?>
        <div class="smv-payment-panel" id="smv-payment-panel-<?php echo esc_attr($reg_id); ?>">
            <div class="smv-payment-header">
                <span class="smv-kicker">پرداخت بلیت</div>
                <h2>مبلغ قابل پرداخت</h2>
                <p class="smv-payment-amount"><?php echo esc_html(SMV_Persian::money($amount)); ?></p>
            </div>
            <div class="smv-payment-methods">
                <button class="smv-payment-btn smv-payment-zarinpal" data-smv-pay="zarinpal" data-reg-id="<?php echo esc_attr($reg_id); ?>" data-amount="<?php echo esc_attr($amount); ?>">
                    <span>🏦</span> پرداخت با زرین‌پال
                </button>
            </div>
            <div class="smv-payment-note">
                <p>اگر قبلاً فیش واریزی آپلود کرده‌اید، نیازی به پرداخت آنلاین نیست. فقط صبر کنید تا فیش توسط مدیریت بررسی شود.</p>
            </div>
        </div>
        <script>
        document.querySelectorAll('[data-smv-pay="zarinpal"]').forEach(function(btn){
            btn.addEventListener('click', function(){
                var regId = this.getAttribute('data-reg-id');
                var amount = this.getAttribute('data-amount');
                fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=smv_verify_payment&registration_id=' + regId + '&amount=' + amount + '&nonce=' + '<?php echo wp_create_nonce('smv_payment_nonce'); ?>'
                }).then(r=>r.json()).then(function(res){
                    if(res.success && res.data.url) {
                        window.location.href = res.data.url;
                    } else {
                        alert(res.data.message || 'خطا در اتصال به درگاه');
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }

    public static function verify_payment() {
        if (!current_user_can('manage_smv_registrations')) {
            wp_die('دسترسی لازم را ندارید.');
        }
        check_admin_referer('smv_payment_nonce');
        $reg_id = isset($_GET['registration_id']) ? absint($_GET['registration_id']) : 0;
        $amount = isset($_GET['amount']) ? absint($_GET['amount']) : 0;
        // منطق تایید پرداخت از زرین‌پال
        wp_safe_redirect(admin_url('admin.php?page=smv-registrations&action=view&id=' . $reg_id));
        exit;
    }

    public static function verify_payment_ajax() {
        check_ajax_referer('smv_payment_nonce', 'nonce');
        $reg_id = absint($_POST['registration_id']);
        $amount = absint($_POST['amount']);
        $merchant = smv_get_option('zarinpal_merchant', '');

        if (!$merchant) {
            wp_send_json_error(array('message' => 'مرچنت زرین‌پال تنظیم نشده است.'));
        }

        $data = array(
            'merchant_id' => $merchant,
            'amount' => $amount,
            'callback_url' => admin_url('admin-post.php?action=smv_verify_payment&registration_id=' . $reg_id),
            'description' => 'پرداخت ثبت‌نام سماویه #'.$reg_id,
        );

        $response = wp_remote_post('https://api.zarinpal.com/pg/v4/payment/request.json', array(
            'method' => 'POST',
            'body' => json_encode($data),
            'headers' => array('Content-Type' => 'application/json', 'Accept' => 'application/json'),
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'خطا در اتصال به درگاه: ' . $response->get_error_message()));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!empty($body['data']['authority'])) {
            $url = 'https://www.zarinpal.com/pg/StartPay/' . $body['data']['authority'];
            wp_send_json_success(array('url' => $url));
        } else {
            wp_send_json_error(array('message' => 'خطا در ایجاد درخواست پرداخت: ' . (isset($body['errors']['message']) ? $body['errors']['message'] : 'نامشخص')));
        }
    }
}
