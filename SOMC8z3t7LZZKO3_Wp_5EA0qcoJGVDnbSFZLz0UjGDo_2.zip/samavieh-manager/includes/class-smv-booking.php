<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * سیستم سانس‌بندی و رزرو با ظرفیت
 */
class SMV_Booking {

    public static function init() {
        add_action('init', array(__CLASS__, 'register_post_types'));
        add_shortcode('samavieh_showtimes', array(__CLASS__, 'showtimes_shortcode'));
        add_shortcode('samavieh_seat_map', array(__CLASS__, 'seat_map_shortcode'));
    }

    public static function register_post_types() {
        register_post_type('smv_showtime', array(
            'labels' => array(
                'name' => 'سانس‌ها',
                'singular_name' => 'سانس',
                'menu_name' => 'سانس‌ها',
                'add_new' => 'افزودن سانس',
                'add_new_item' => 'افزودن سانس جدید',
                'edit_item' => 'ویرایش سانس',
                'new_item' => 'سانس جدید',
                'view_item' => 'مشاهده سانس',
                'search_items' => 'جست‌وجوی سانس‌ها',
                'not_found' => 'هنوز سانسی اضافه نشده است.',
                'not_found_in_trash' => 'سانسی در زباله‌دان نیست.',
            ),
            'public' => true,
            'show_in_rest' => true,
            'show_in_menu' => 'smv-dashboard',
            'menu_icon' => 'dashicons-calendar',
            'supports' => array('title', 'editor', 'custom-fields', 'revisions'),
            'has_archive' => false,
            'rewrite' => array('slug' => 'showtime', 'with_front' => false),
            'capability_type' => array('smv_showtime', 'smv_showtimes'),
            'map_meta_cap' => true,
        ));
    }

    public static function showtimes_shortcode($atts) {
        $atts = shortcode_atts(array(
            'theatre_id' => 0,
            'count' => -1,
            'columns' => 3,
        ), $atts, 'samavieh_showtimes');

        $args = array(
            'post_type' => 'smv_showtime',
            'post_status' => 'publish',
            'posts_per_page' => max(-1, (int) $atts['count']),
            'orderby' => 'meta_value',
            'meta_key' => '_smv_showtime_date',
            'order' => 'ASC',
            'no_found_rows' => true,
        );
        if ($atts['theatre_id']) {
            $args['meta_query'] = array(array(
                'key' => '_smv_theatre_id',
                'value' => absint($atts['theatre_id']),
                'compare' => '=',
            ));
        }

        $query = new WP_Query($args);
        $columns = min(4, max(1, absint($atts['columns'])));
        ob_start();
        if ($query->have_posts()) :
            echo '<div class="smv-showtime-grid smv-columns-' . esc_attr($columns) . '">';
            while ($query->have_posts()) : $query->the_post();
                $id = get_the_ID();
                $date = get_post_meta($id, '_smv_showtime_date', true);
                $time = get_post_meta($id, '_smv_showtime_time', true);
                $venue = get_post_meta($id, '_smv_showtime_venue', true);
                $capacity = absint(get_post_meta($id, '_smv_capacity', true));
                $booked = absint(get_post_meta($id, '_smv_booked', true));
                $price = get_post_meta($id, '_smv_showtime_price', true);
                $remaining = max(0, $capacity - $booked);
                $percent = $capacity ? round(($booked / $capacity) * 100) : 0;
                $is_full = $remaining <= 0;
                ?>
                <article class="smv-showtime-card<?php echo $is_full ? ' is-full' : ''; ?>">
                    <div class="smv-showtime-header">
                        <span class="smv-showtime-date"><?php echo esc_html(SMV_Persian::date($date)); ?></span>
                        <span class="smv-showtime-time"><?php echo esc_html($time); ?></span>
                        <?php if ($is_full) : ?><span class="smv-showtime-full">تمام</span><?php endif; ?>
                    </div>
                    <div class="smv-showtime-body">
                        <h4><?php the_title(); ?></h4>
                        <p class="smv-showtime-venue"><?php echo esc_html($venue); ?></p>
                        <div class="smv-showtime-capacity">
                            <span>ظرفیت: <?php echo esc_html(SMV_Persian::digits($remaining)); ?> / <?php echo esc_html(SMV_Persian::digits($capacity)); ?></span>
                            <div class="smv-progress-bar"><div class="smv-progress-fill" style="width:<?php echo esc_attr($percent); ?>%"></div></div>
                            <span class="smv-showtime-percent"><?php echo esc_html(SMV_Persian::digits($percent)); ?>%</span>
                        </div>
                        <?php if ($price) : ?><p class="smv-showtime-price"><?php echo esc_html(SMV_Persian::money($price)); ?></p><?php endif; ?>
                    </div>
                    <div class="smv-showtime-footer">
                        <?php if ($is_full) : ?>
                            <button class="smv-button smv-button-ghost" disabled>سرانه capacities</button>
                        <?php else : ?>
                            <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=smv_book_seat&showtime_id=' . $id)); ?>" class="smv-button smv-button-primary">رزرو صندلی</a>
                        <?php endif; ?>
                    </div>
                </article>
                <?php
            endwhile;
            echo '</div>';
        else :
            echo '<div class="smv-empty"><h3>سانسی برای این اجرا برنامه‌ریزی نشده است</h3><p>به‌زودی سانس‌های جدید اضافه می‌شود.</p></div>';
        endif;
        wp_reset_postdata();
        return ob_get_clean();
    }

    public static function seat_map_shortcode($atts) {
        $atts = shortcode_atts(array('showtime_id' => 0), $atts, 'samavieh_seat_map');
        $id = absint($atts['showtime_id']);
        if (!$id) {
            return '<div class="smv-notice">سانس مشخص نشده است.</div>';
        }
        $capacity = absint(get_post_meta($id, '_smv_capacity', true));
        $booked = maybe_unserialize(get_post_meta($id, '_smv_booked_seats', true));
        if (!$booked) $booked = array();
        ob_start();
        ?>
        <div class="smv-seat-map" id="smv-seat-map-<?php echo esc_attr($id); ?>">
            <div class="smv-seat-legend">
                <span class="smv-seat-status free"></span> خالی
                <span class="smv-seat-status booked"></span> رزرو شده
                <span class="smv-seat-status selected"></span> انتخاب شده
            </div>
            <div class="smv-seat-grid" data-showtime-id="<?php echo esc_attr($id); ?>" data-booked="<?php echo esc_attr(implode(',', $booked)); ?>" data-capacity="<?php echo esc_attr($capacity); ?>">
                <?php for ($i = 1; $i <= $capacity; $i++) : $is_booked = in_array($i, $booked, true); ?>
                    <button class="smv-seat<?php echo $is_booked ? ' booked' : ''; ?>" data-seat-number="<?php echo esc_attr($i); ?>" <?php echo $is_booked ? 'disabled' : ''; ?>><?php echo esc_html($i); ?></button>
                <?php endfor; ?>
            </div>
            <div class="smv-seat-result" style="display:none;">
                <strong>صندلی‌های انتخاب‌شده:</strong> <span class="smv-selected-seats"></span>
                <button class="smv-button smv-button-primary smv-confirm-seats">تایید انتخاب</button>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function book_seat_ajax() {
        check_ajax_referer('smv_booking_nonce', 'nonce');
        $showtime_id = absint($_POST['showtime_id']);
        $seat_number = absint($_POST['seat_number']);
        // ذخیره در متا
        global $wpdb;
        $table = smv_table_name();
        // اینجا می‌توان رزرو صندلی را در جدول رزرو‌ها ذخیره کرد
        wp_send_json_success(array('message' => 'صندلی رزرو شد.'));
    }
}

add_action('wp_ajax_smv_book_seat', array('SMV_Booking', 'book_seat_ajax'));
add_action('wp_ajax_nopriv_smv_book_seat', array('SMV_Booking', 'book_seat_ajax'));
