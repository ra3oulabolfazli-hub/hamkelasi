<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * نمایش توییت‌ها و محتوای شبکه‌های اجتماعی با محیط گرافیکی
 */
class SMV_Social {

    public static function init() {
        add_shortcode('samavieh_social', array(__CLASS__, 'social_shortcode'));
        add_shortcode('samavieh_tweets', array(__CLASS__, 'tweets_shortcode'));
    }

    public static function social_shortcode($atts) {
        $atts = shortcode_atts(array(
            'platform' => 'instagram',
            'count' => 6,
        ), $atts, 'samavieh_social');

        $url = smv_get_option($atts['platform']);
        if (!$url) {
            return '<div class="smv-empty"><p>لینک ' . esc_html($atts['platform']) . ' تنظیم نشده است.</p></div>';
        }

        ob_start();
        ?>
        <div class="smv-social-profile">
            <div class="smv-social-header">
                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">
                    <span class="smv-social-icon"><?php echo self::icon($atts['platform']); ?></span>
                    <span class="smv-social-name"><?php echo esc_html(ucfirst($atts['platform'])); ?></span>
                </a>
            </div>
            <div class="smv-social-grid" data-platform="<?php echo esc_attr($atts['platform']); ?>" data-count="<?php echo esc_attr(absint($atts['count'])); ?>">
                <!-- محتوای شبکه اجتماعی با JavaScript بارگذاری می‌شود -->
                <div class="smv-social-loading"><?php echo smv_icon('clock'); ?> بارگذاری...</div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function tweets_shortcode($atts) {
        $atts = shortcode_atts(array(
            'username' => '',
            'count' => 5,
        ), $atts, 'samavieh_tweets');

        if (!$atts['username']) {
            return '<div class="smv-empty"><p>نام کاربری توییتر تنظیم نشده است.</p></div>';
        }

        ob_start();
        ?>
        <div class="smv-tweets-carousel">
            <div class="smv-tweets-header">
                <span class="smv-twitter-icon">🐦</span>
                <h3>توییت‌های اخیر <?php echo esc_html('@' . $atts['username']); ?></h3>
            </div>
            <div class="smv-tweets-grid" data-username="<?php echo esc_attr($atts['username']); ?>" data-count="<?php echo esc_attr(absint($atts['count'])); ?>">
                <div class="smv-tweet-loading"><?php echo smv_icon('clock'); ?> بارگذاری توییت‌ها...</div>
            </div>
            <a href="https://twitter.com/<?php echo esc_attr($atts['username']); ?>" target="_blank" rel="noopener noreferrer" class="smv-tweets-more">مشاهده همه توییت‌ها</a>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function icon($platform) {
        $icons = array(
            'instagram' => '📷',
            'telegram' => '✈️',
            'whatsapp' => '💬',
            'twitter' => '🐦',
            'youtube' => '▶️',
        );
        return $icons[$platform] ?? '🔗';
    }
}
