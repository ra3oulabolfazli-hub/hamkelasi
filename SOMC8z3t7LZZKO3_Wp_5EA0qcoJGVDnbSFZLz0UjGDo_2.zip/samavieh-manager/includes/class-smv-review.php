<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * سیستم نظرات و بررسی‌ها (حداکثر ۲ نظر به هر اثر/اجرا)
 */
class SMV_Review {

    public static function init() {
        add_action('init', array(__CLASS__, 'register_post_type'));
        add_shortcode('samavieh_reviews', array(__CLASS__, 'reviews_shortcode'));
        add_action('wp_ajax_smv_submit_review', array(__CLASS__, 'submit_ajax'));
        add_action('wp_ajax_nopriv_smv_submit_review', array(__CLASS__, 'submit_ajax'));
    }

    public static function register_post_type() {
        register_post_type('smv_review', array(
            'labels' => array(
                'name' => 'نظرات',
                'singular_name' => 'نظر',
                'menu_name' => 'نظرات',
                'add_new' => 'افزودن نظر',
                'add_new_item' => 'افزودن نظر جدید',
                'edit_item' => 'ویرایش نظر',
                'new_item' => 'نظر جدید',
                'view_item' => 'مشاهده نظر',
                'search_items' => 'جست‌وجو نظرات',
                'not_found' => 'هنوز نظری اضافه نشده است.',
                'not_found_in_trash' => 'نظری در زباله‌دان نیست.',
            ),
            'public' => true,
            'show_in_rest' => true,
            'show_in_menu' => 'smv-dashboard',
            'menu_icon' => 'dashicons-format-status',
            'supports' => array('title', 'editor', 'custom-fields', 'thumbnail'),
            'has_archive' => false,
            'rewrite' => array('slug' => 'review', 'with_front' => false),
            'capability_type' => array('smv_review', 'smv_reviews'),
            'map_meta_cap' => true,
        ));
    }

    public static function reviews_shortcode($atts) {
        $atts = shortcode_atts(array(
            'theatre_id' => 0,
            'count' => 2,
            'approved_only' => 1,
        ), $atts, 'samavieh_reviews');

        $args = array(
            'post_type' => 'smv_review',
            'post_status' => 'publish',
            'posts_per_page' => absint($atts['count']),
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
        );
        if ($atts['theatre_id']) {
            $args['meta_query'] = array(array(
                'key' => '_smv_review_theatre_id',
                'value' => absint($atts['theatre_id']),
                'compare' => '=',
            ));
        }
        if (!empty($atts['approved_only'])) {
            $args['meta_query'][] = array(
                'key' => '_smv_review_status',
                'value' => 'approved',
                'compare' => '=',
            );
        }

        $query = new WP_Query($args);
        ob_start();
        if ($query->have_posts()) :
            echo '<div class="smv-reviews-grid">';
            while ($query->have_posts()) : $query->the_post();
                $id = get_the_ID();
                $rating = absint(get_post_meta($id, '_smv_review_rating', true));
                $author = get_post_meta($id, '_smv_review_author', true) ?: 'ناشناس';
                $status = get_post_meta($id, '_smv_review_status', true);
                ?>
                <article class="smv-review-card">
                    <div class="smv-review-header">
                        <span class="smv-review-author"><?php echo esc_html($author); ?></span>
                        <span class="smv-review-rating"><?php echo self::stars($rating); ?></span>
                    </div>
                    <div class="smv-review-body"><?php echo esc_html(get_the_excerpt($id)); ?></div>
                    <span class="smv-review-status status-<?php echo esc_attr($status); ?>"><?php echo esc_html(smv_status_label($status)); ?></span>
                </article>
                <?php
            endwhile;
            echo '</div>';
        else :
            echo '<div class="smv-empty"><p>هر نظری برای نمایش وجود ندارد.</p></div>';
        endif;
        wp_reset_postdata();
        return ob_get_clean();
    }

    private static function stars($rating) {
        $html = '';
        for ($i = 1; $i <= 5; $i++) {
            $html .= '<span class="smv-star' . ($i <= $rating ? ' filled' : '') . '">★</span>';
        }
        return $html;
    }

    public static function submit_ajax() {
        check_ajax_referer('smv_review_nonce', 'nonce');
        $theatre_id = absint($_POST['theatre_id']);
        $author = sanitize_text_field($_POST['author'] ?? '');
        $comment = sanitize_textarea_field($_POST['comment'] ?? '');
        $rating = absint($_POST['rating'] ?? 0);

        if (!$author || !$comment || !$rating || $rating < 1 || $rating > 5) {
            wp_send_json_error(array('message' => 'تمام موارد را به درستی پر کنید.'));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'smv_reviews';
        // بررسی تعداد نظرات تایید شده (حداکثر ۲)
        $approved_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE theatre_id = %d AND status = 'approved'", $theatre_id));
        if ($approved_count >= 2) {
            wp_send_json_error(array('message' => 'حداکثر دو نظر برای این اجرا ثبت شده است.'));
        }

        $wpdb->insert($table, array(
            'theatre_id' => $theatre_id,
            'author' => $author,
            'comment' => $comment,
            'rating' => $rating,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ), array('%d', '%s', '%s', '%d', '%s', '%s'));

        wp_send_json_success(array('message' => 'نظر شما ثبت شد و پس از تایید مدیریت نمایش داده می‌شود.'));
    }
}

// ایجاد جدول نظرات در هنگام فعال‌سازی
function smv_create_reviews_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'smv_reviews';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        theatre_id bigint(20) NOT NULL,
        author varchar(200) NOT NULL,
        comment text NOT NULL,
        rating tinyint(1) NOT NULL DEFAULT 0,
        status varchar(20) NOT NULL DEFAULT 'pending',
        created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        PRIMARY KEY (id),
        KEY theatre_id (theatre_id)
    ) {$charset_collate};";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'smv_create_reviews_table');
