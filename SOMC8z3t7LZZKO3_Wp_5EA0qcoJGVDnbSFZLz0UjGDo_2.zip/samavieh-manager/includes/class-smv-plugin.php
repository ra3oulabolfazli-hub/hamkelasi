<?php
if (!defined('ABSPATH')) {
    exit;
}

final class SMV_Plugin {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        SMV_CPT::init();
        SMV_Meta::init();
        SMV_Settings::init();
        SMV_Forms::init();
        SMV_Shortcodes::init();
        SMV_Admin::init();
        SMV_Elementor::init();

        add_action('init', array($this, 'maybe_upgrade_db'), 5);
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_filter('body_class', array($this, 'body_class'));
        add_filter('the_content', array($this, 'single_theatre_content'), 20);
    }

    public function maybe_upgrade_db() {
        if (get_option('smv_db_version') !== SMV_DB_VERSION) {
            SMV_Activator::create_tables();
        }
    }

    public function register_assets() {
        wp_register_style(
            'smv-frontend',
            SMV_URL . 'assets/css/frontend.css',
            array(),
            SMV_VERSION
        );
        wp_register_script(
            'smv-frontend',
            SMV_URL . 'assets/js/frontend.js',
            array(),
            SMV_VERSION,
            true
        );
        wp_localize_script('smv-frontend', 'smvFrontend', array(
            'copied' => 'کد پیگیری کپی شد.',
            'copy' => 'کپی کد',
            'sending' => 'در حال ارسال…',
            'maxSize' => (int) smv_get_option('receipt_max_size', 5) * MB_IN_BYTES,
            'sizeError' => 'حجم فایل بیشتر از حد مجاز است.',
        ));
    }

    public static function enqueue_frontend() {
        wp_enqueue_style('smv-frontend');
        wp_enqueue_script('smv-frontend');
    }

    public function body_class($classes) {
        $classes[] = 'smv-site';
        return $classes;
    }

    public function single_theatre_content($content) {
        if (is_admin() || !is_singular('smv_theatre') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (defined('ELEMENTOR_VERSION') && class_exists('\Elementor\Plugin')) {
            $editor = \Elementor\Plugin::instance()->editor;
            if ($editor && $editor->is_edit_mode()) {
                return $content;
            }
        }

        $before = '';
        $after = '';
        $elementor_data = get_post_meta(get_the_ID(), '_elementor_data', true);
        $elementor_data = is_string($elementor_data) ? $elementor_data : '';
        $has_details_widget = (false !== strpos($elementor_data, 'smv-theatre-details') || false !== strpos($elementor_data, 'samavieh_theatre_details'));
        $has_registration_widget = (false !== strpos($elementor_data, 'smv-registration') || false !== strpos($elementor_data, 'samavieh_registration'));

        if (!has_shortcode($content, 'samavieh_theatre_details') && !$has_details_widget) {
            $before = do_shortcode('[samavieh_theatre_details]');
        }
        if (!has_shortcode($content, 'samavieh_registration') && !$has_registration_widget) {
            $after = do_shortcode('[samavieh_registration]');
        }

        return $before . $content . $after;
    }
}
