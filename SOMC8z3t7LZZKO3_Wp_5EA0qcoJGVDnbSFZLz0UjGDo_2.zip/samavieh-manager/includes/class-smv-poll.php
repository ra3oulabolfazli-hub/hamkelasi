<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * سیستمنظرسنجی (Poll / Survey)
 */
class SMV_Poll {

    public static function init() {
        add_action('init', array(__CLASS__, 'register_post_type'));
        add_shortcode('samavieh_poll', array(__CLASS__, 'poll_shortcode'));
        add_action('wp_ajax_smv_vote_poll', array(__CLASS__, 'vote_ajax'));
        add_action('wp_ajax_nopriv_smv_vote_poll', array(__CLASS__, 'vote_ajax'));
    }

    public static function register_post_type() {
        register_post_type('smv_poll', array(
            'labels' => array(
                'name' => 'نظرسنجی‌ها',
                'singular_name' => 'نظرسنجی',
                'menu_name' => 'نظرسنجی‌ها',
                'add_new' => 'افزودننظرسنجی',
                'add_new_item' => 'افزودننظرسنجی جدید',
                'edit_item' => 'ویرایشنظرسنجی',
                'new_item' => 'نظرسنجی جدید',
                'view_item' => 'مشاهدهنظرسنجی',
                'search_items' => 'جست‌وجوینظرسنجی‌ها',
                'not_found' => 'هنوزنظرسنجی‌ای اضافه نشده است.',
                'not_found_in_trash' => 'نظرسنجی در زباله‌دان نیست.',
            ),
            'public' => true,
            'show_in_rest' => true,
            'show_in_menu' => 'smv-dashboard',
            'menu_icon' => 'dashicons-chart-pie',
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => array('slug' => 'poll', 'with_front' => false),
        ));
    }

    public static function poll_shortcode($atts) {
        $atts = shortcode_atts(array('id' => 0), $atts, 'samavieh_poll');
        $id = absint($atts['id'] ?: get_queried_object_id());
        if (!$id || 'smv_poll' !== get_post_type($id)) {
            return '';
        }

        $title = get_post_meta($id, '_smv_poll_title', true) ?: get_the_title($id);
        $description = get_post_meta($id, '_smv_poll_description', true);
        $start_date = get_post_meta($id, '_smv_poll_start_date', true);
        $end_date = get_post_meta($id, '_smv_poll_end_date', true);
        $status = get_post_meta($id, '_smv_poll_status', true) ?: 'active';
        $answers = maybe_unserialize(get_post_meta($id, '_smv_poll_answers', true));
        if (!$answers) $answers = array();

        $user_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $has_voted = false;
        if (!empty($user_ip)) {
            $votes = get_option('smv_poll_votes_' . $id, array());
            $has_voted = in_array($user_ip, $votes, true);
        }

        $total_votes = 0;
        foreach ($answers as $ans) $total_votes += absint($ans['votes']);

        ob_start();
        ?>
        <div class="smv-poll-panel" id="smv-poll-<?php echo esc_attr($id); ?>">
            <div class="smv-poll-header">
                <h3><?php echo esc_html($title); ?></h3>
                <?php if ($description) : ?><p><?php echo esc_html($description); ?></p><?php endif; ?>
                <?php if ($status !== 'active') : ?><span class="smv-poll-closed">نظرسنجی بسته شده است</span><?php endif; ?>
            </div>

            <?php if ($has_voted || $status !== 'active') : ?>
                <div class="smv-poll-results">
                    <?php foreach ($answers as $ans) : $percent = $total_votes ? round(($ans['votes'] / $total_votes) * 100) : 0; ?>
                        <div class="smv-poll-result-item">
                            <span class="smv-poll-answer-text"><?php echo esc_html($ans['text']); ?></span>
                            <div class="smv-poll-progress"><div class="smv-poll-progress-fill" style="width:<?php echo esc_attr($percent); ?>%"></div></div>
                            <span class="smv-poll-vote-count"><?php echo esc_html(SMV_Persian::digits($ans['votes'])); ?> رای (<?php echo esc_html(SMV_Persian::digits($percent)); ?>%)</span>
                        </div>
                    <?php endforeach; ?>
                    <div class="smv-poll-total">کل رای‌ها: <?php echo esc_html(SMV_Persian::digits($total_votes)); ?></div>
                </div>
            <?php else : ?>
                <form class="smv-poll-form" id="smv-poll-form-<?php echo esc_attr($id); ?>">
                    <?php foreach ($answers as $idx => $ans) : ?>
                        <label class="smv-poll-option">
                            <input type="radio" name="smv_poll_answer" value="<?php echo esc_attr($idx); ?>" required />
                            <span><?php echo esc_html($ans['text']); ?></span>
                        </label>
                    <?php endforeach; ?>
                    <button type="submit" class="smv-button smv-button-primary smv-poll-submit">ارسال رای</button>
                </form>
                <div class="smv-poll-message" id="smv-poll-message-<?php echo esc_attr($id); ?>" style="display:none;"></div>
            <?php endif; ?>
        </div>

        <script>
        document.getElementById('smv-poll-form-<?php echo esc_attr($id); ?>')?.addEventListener('submit', function(e){
            e.preventDefault();
            var form = this;
            var answer = form.querySelector('input[name="smv_poll_answer"]:checked');
            if(!answer) return;
            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=smv_vote_poll&poll_id=<?php echo esc_attr($id); ?>&answer_index=' + answer.value + '&nonce=<?php echo wp_create_nonce('smv_poll_nonce'); ?>'
            }).then(r=>r.json()).then(function(res){
                var msg = document.getElementById('smv-poll-message-<?php echo esc_attr($id); ?>');
                if(res.success){
                    form.style.display='none';
                    msg.style.display='block';
                    msg.innerHTML='رای شما با موفقیت ثبت شد.';
                    location.reload();
                } else {
                    msg.style.display='block';
                    msg.innerHTML=res.data.message || 'خطا در ثبت رای';
                }
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }

    public static function vote_ajax() {
        check_ajax_referer('smv_poll_nonce', 'nonce');
        $poll_id = absint($_POST['poll_id']);
        $answer_index = absint($_POST['answer_index']);

        $answers = maybe_unserialize(get_post_meta($poll_id, '_smv_poll_answers', true));
        if (!$answers || !isset($answers[$answer_index])) {
            wp_send_json_error(array('message' => 'پاسخ نامعتبر است.'));
        }

        $user_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $votes = get_option('smv_poll_votes_' . $poll_id, array());
        if (in_array($user_ip, $votes, true)) {
            wp_send_json_error(array('message' => 'شما قبلاً در ایننظرسنجی رای داده‌اید.'));
        }

        $answers[$answer_index]['votes'] = absint($answers[$answer_index]['votes'] ?? 0) + 1;
        update_post_meta($poll_id, '_smv_poll_answers', serialize($answers));
        $votes[] = $user_ip;
        update_option('smv_poll_votes_' . $poll_id, $votes);

        wp_send_json_success(array('message' => 'رای شما ثبت شد.'));
    }
}
