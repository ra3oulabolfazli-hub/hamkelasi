<?php
if (!defined('ABSPATH')) {
    exit;
}

class SMV_Meta {
    public static function init() {
        add_action('add_meta_boxes', array(__CLASS__, 'add_boxes'));
        add_action('save_post_smv_theatre', array(__CLASS__, 'save_theatre'));
        add_action('save_post_smv_project', array(__CLASS__, 'save_project'));
    }

    public static function add_boxes() {
        add_meta_box('smv-theatre-details', 'اطلاعات اجرا و ثبت‌نام', array(__CLASS__, 'theatre_box'), 'smv_theatre', 'normal', 'high');
        add_meta_box('smv-project-details', 'اطلاعات تکمیلی پروژه', array(__CLASS__, 'project_box'), 'smv_project', 'normal', 'high');
    }

    private static function field($post_id, $key, $label, $type = 'text', $description = '', $options = array()) {
        $meta_key = '_smv_' . $key;
        $value = get_post_meta($post_id, $meta_key, true);
        $id = 'smv-' . str_replace('_', '-', $key);
        echo '<div class="smv-admin-field">';
        echo '<label for="' . esc_attr($id) . '"><strong>' . esc_html($label) . '</strong></label>';
        if ('select' === $type) {
            echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($meta_key) . '">';
            foreach ($options as $option_value => $option_label) {
                echo '<option value="' . esc_attr($option_value) . '" ' . selected($value, $option_value, false) . '>' . esc_html($option_label) . '</option>';
            }
            echo '</select>';
        } elseif ('textarea' === $type) {
            echo '<textarea id="' . esc_attr($id) . '" name="' . esc_attr($meta_key) . '" rows="3">' . esc_textarea($value) . '</textarea>';
        } else {
            $extra = ('number' === $type) ? ' min="0" step="1"' : '';
            echo '<input type="' . esc_attr($type) . '" id="' . esc_attr($id) . '" name="' . esc_attr($meta_key) . '" value="' . esc_attr($value) . '"' . $extra . ' />';
        }
        if ($description) {
            echo '<small>' . esc_html($description) . '</small>';
        }
        echo '</div>';
    }

    public static function theatre_box($post) {
        wp_nonce_field('smv_save_theatre_meta', 'smv_theatre_meta_nonce');
        echo '<p class="smv-admin-help">فقط همین مشخصات را وارد کنید. برای توضیحات کامل از ویرایشگر بالای صفحه یا دکمهٔ «ویرایش با المنتور» استفاده کنید و تصویر اصلی را از بخش «تصویر شاخص» انتخاب کنید.</p>';
        echo '<div class="smv-admin-grid">';
        self::field($post->ID, 'director', 'کارگردان');
        self::field($post->ID, 'writer', 'نویسنده');
        self::field($post->ID, 'start_date', 'تاریخ شروع اجرا', 'date');
        self::field($post->ID, 'end_date', 'تاریخ پایان اجرا', 'date', 'اگر اجرا یکروزه است، خالی بماند.');
        self::field($post->ID, 'show_time', 'ساعت اجرا', 'text', 'مثال: ۱۸:۰۰ و ۲۰:۰۰');
        self::field($post->ID, 'duration', 'مدت اجرا', 'text', 'مثال: ۷۰ دقیقه');
        self::field($post->ID, 'age_range', 'ردهٔ سنی', 'text', 'مثال: مناسب ۱۲ سال به بالا');
        self::field($post->ID, 'venue', 'محل اجرا');
        self::field($post->ID, 'price', 'مبلغ ثبت‌نام (تومان)', 'number', 'برای ثبت‌نام رایگان عدد صفر را وارد کنید.');
        self::field($post->ID, 'capacity', 'ظرفیت', 'number', 'صفر یعنی بدون محدودیت ظرفیت.');
        self::field($post->ID, 'registration_deadline', 'آخرین مهلت ثبت‌نام', 'date');
        self::field($post->ID, 'registration_status', 'وضعیت ثبت‌نام', 'select', '', array('open' => 'باز است', 'closed' => 'بسته است'));
        echo '</div>';
    }

    public static function project_box($post) {
        wp_nonce_field('smv_save_project_meta', 'smv_project_meta_nonce');
        echo '<div class="smv-admin-grid">';
        self::field($post->ID, 'project_year', 'سال اجرا', 'text', 'مثال: ۱۴۰۵');
        self::field($post->ID, 'project_status', 'وضعیت پروژه', 'select', '', array('completed' => 'انجام شده', 'ongoing' => 'در حال اجرا'));
        echo '</div>';
    }

    private static function can_save($post_id, $nonce_name, $action) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return false;
        }
        if (!isset($_POST[$nonce_name]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[$nonce_name])), $action)) {
            return false;
        }
        return current_user_can('edit_post', $post_id);
    }

    public static function save_theatre($post_id) {
        if (!self::can_save($post_id, 'smv_theatre_meta_nonce', 'smv_save_theatre_meta')) {
            return;
        }
        $text_fields = array('director', 'writer', 'show_time', 'duration', 'age_range', 'venue');
        $date_fields = array('start_date', 'end_date', 'registration_deadline');
        $number_fields = array('price', 'capacity');
        foreach ($text_fields as $key) {
            $value = isset($_POST['_smv_' . $key]) ? sanitize_text_field(wp_unslash($_POST['_smv_' . $key])) : '';
            update_post_meta($post_id, '_smv_' . $key, $value);
        }
        foreach ($date_fields as $key) {
            $value = isset($_POST['_smv_' . $key]) ? sanitize_text_field(wp_unslash($_POST['_smv_' . $key])) : '';
            if ($value && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                $value = '';
            }
            update_post_meta($post_id, '_smv_' . $key, $value);
        }
        foreach ($number_fields as $key) {
            $value = isset($_POST['_smv_' . $key]) ? absint($_POST['_smv_' . $key]) : 0;
            update_post_meta($post_id, '_smv_' . $key, $value);
        }
        $status = isset($_POST['_smv_registration_status']) && 'open' === $_POST['_smv_registration_status'] ? 'open' : 'closed';
        update_post_meta($post_id, '_smv_registration_status', $status);
    }

    public static function save_project($post_id) {
        if (!self::can_save($post_id, 'smv_project_meta_nonce', 'smv_save_project_meta')) {
            return;
        }
        $year = isset($_POST['_smv_project_year']) ? sanitize_text_field(wp_unslash($_POST['_smv_project_year'])) : '';
        $status = isset($_POST['_smv_project_status']) && 'ongoing' === $_POST['_smv_project_status'] ? 'ongoing' : 'completed';
        update_post_meta($post_id, '_smv_project_year', $year);
        update_post_meta($post_id, '_smv_project_status', $status);
    }
}
